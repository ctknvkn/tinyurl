﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Text;
using System.Security.Cryptography;
using System.Collections.Concurrent;
using Microsoft.VisualBasic.FileIO;
using System.Threading;

public class KannappanTinyUrl 
{ 
    static ConcurrentDictionary<string, string> urlDictionary = new ConcurrentDictionary<string, string>();
    static ConcurrentDictionary<string, int> urlCountDictionary = new ConcurrentDictionary<string, int>();

    
    
    
public static string GetShortUrl(string? url)
    {
         string shortUrl = ComputeStringToSha256Hash(url);
         shortUrl = shortUrl.Replace('/', '-').Replace('+', '_').Substring(0, 6);
         shortUrl =  "tinyurl.com/" + shortUrl;
         bool urlItem = urlDictionary.TryAdd(shortUrl,url); 
         return shortUrl;
        
    }

    public static string ComputeStringToSha256Hash(string plainText)
        {
            // Create a SHA256 hash from string   
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // Computing Hash - returns here byte array
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(plainText));

                // now convert byte array to a string   
                StringBuilder stringbuilder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    stringbuilder.Append(bytes[i].ToString("x2"));
                }
                return stringbuilder.ToString();
            }
        }
    public static string GetLongUrl(string? shorturl)
    {
        string? longUrl = "";
        int currentlinkHitCount = 0;
        int newlinkHitCount = 0;
        string shorturlHitCountKey = shorturl + "LinkHitCount";
        if(urlDictionary.TryGetValue(shorturl, out longUrl))
           {
             if(!urlCountDictionary.ContainsKey(shorturlHitCountKey))
            urlCountDictionary.TryAdd(shorturlHitCountKey, 0);
            urlCountDictionary.TryGetValue(shorturlHitCountKey, out currentlinkHitCount);
            newlinkHitCount = currentlinkHitCount;
            Interlocked.Increment(ref newlinkHitCount);
            urlCountDictionary.TryUpdate(shorturlHitCountKey,newlinkHitCount,currentlinkHitCount);
            return longUrl;
        }

        return shorturl;
    }

    public static int? getHitStatisticss(string ?shortUrl)
    {
        int shortUrlLinkHitCount = 0;
        string shorturlHitCountKey = shortUrl + "LinkHitCount";
        urlCountDictionary.TryGetValue(shorturlHitCountKey, out shortUrlLinkHitCount);
        return shortUrlLinkHitCount;
        
    }
    public static string? DeleteShortUrl(string? shortUrl)
    {
          string? removedItem="";
         if(urlDictionary.ContainsKey(shortUrl))
         {
            bool result = urlDictionary.TryRemove(shortUrl, out removedItem);
            if(!result)
            return "shortUrl not present";
         }
         return removedItem  + " - URL removed";
    }

 // Driver Code 
    public static void Main(String[] args) 
    { 
        bool knownKeyPressed = false;

        do
        {
            Console.WriteLine("Press 1 for generating Short URL, 2 for getting Long URL using Short URL , 3 to Delete an existing short URL, 4 to get statistics on short url hit...");

            ConsoleKeyInfo keyReaded = Console.ReadKey();

            switch (keyReaded.Key)
            {
                case ConsoleKey.D1: //Number 1 Key
                    Console.WriteLine("Number 1 was pressed");
        
                    Console.WriteLine("Enter URL to shorten :");
                    string? longURL = Console.ReadLine();
                    if(longURL.Trim() != "")
                    {
                    String shorturl = GetShortUrl(longURL);  
                    Console.WriteLine("Generated short url is " + shorturl);  
                    }
                    else
                    Console.WriteLine("The URL is not valid , please key in valid URL ");
                    

            

                    //knownKeyPressed = true;
                    break;

                case ConsoleKey.D2: //Number 2 Key
                    Console.WriteLine("Number 2 was pressed");
                    Console.WriteLine("Enter short URL to get long URL :");
                    string? shorturlopt =  Console.ReadLine();
                     if(urlDictionary.ContainsKey(shorturlopt))
                    {
                    String longurl = GetLongUrl(shorturlopt);  
                    Console.WriteLine("the long url is " + longurl);  
                    }
                     else
                    Console.WriteLine("The short URL is not valid, please key in valid URL  ");

                    //knownKeyPressed = true;
                    break;
                case ConsoleKey.D3: //Number 3 Key
                    Console.WriteLine("Number 3 was pressed");
                    Console.WriteLine("Enter short URL to delete :");
                    string? shorturlopt3 =  Console.ReadLine();
                      if(urlDictionary.ContainsKey(shorturlopt3))
                    {
                    String? result = DeleteShortUrl(shorturlopt3);  
                    Console.WriteLine("Deletion status:" + result);  
                    }
                    else
                    Console.WriteLine("The short URL is not valid , please key in valid URL ");

                    //knownKeyPressed = true;
                    break;
              case ConsoleKey.D4: //Number 4 Key
                    Console.WriteLine("Number 4 was pressed");
                    Console.WriteLine("Enter short URL to get statistics on number of hits :");
                    string? shorturlopt4 =  Console.ReadLine();
                    if(urlDictionary.ContainsKey(shorturlopt4))
                    {
                    int? hitresult = getHitStatisticss(shorturlopt4);  
                    Console.WriteLine("The number of hits for url - " + shorturlopt4 + " is :" + hitresult.ToString());  
                    }
                    else
                    Console.WriteLine("The short URL is not valid , please key in valid URL ");

                    //knownKeyPressed = true;
                    break;
                default: //Not known key pressed
                    Console.WriteLine("Wrong key, please try again.");
                    knownKeyPressed = false;
                    break;
            }
        } while(!knownKeyPressed);
        
    } 
} 